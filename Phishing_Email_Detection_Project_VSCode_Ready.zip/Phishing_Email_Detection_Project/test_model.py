"""Smoke test for the trained phishing email model. Run after train_model.py."""
from pathlib import Path
import joblib

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "phishing_model.joblib"

def main():
    if not MODEL_PATH.exists():
        raise SystemExit("Model not found. Run: python train_model.py")
    model = joblib.load(MODEL_PATH)
    examples = [
        "URGENT verify your password now at http://account-check.example",
        "Hello team, our project meeting is tomorrow at 10 AM.",
    ]
    predictions = model.predict(examples)
    for text, label in zip(examples, predictions):
        print(f"Prediction: {str(label).upper()} | Email: {text}")
    if len(predictions) != 2 or not set(predictions).issubset({"phishing", "safe"}):
        raise SystemExit("Smoke test failed: unexpected predictions.")
    print("Smoke test completed. Predictions are illustrative, not a security guarantee.")

if __name__ == "__main__":
    main()
