@echo off
setlocal
cd /d "%~dp0"
title Phishing Email Detection - Setup and Run

echo ======================================================
echo       PHISHING EMAIL DETECTION PROJECT
echo ======================================================
echo.

if not exist ".venv\Scripts\python.exe" (
    echo [1/4] Creating a Python virtual environment...
    where py >nul 2>nul
    if not errorlevel 1 (
        py -3 -m venv .venv
    ) else (
        where python >nul 2>nul
        if errorlevel 1 goto no_python
        python -m venv .venv
    )
    if errorlevel 1 (
        echo ERROR: Could not create the virtual environment.
        pause
        exit /b 1
    )
)

echo.
echo [2/4] Installing required libraries (internet is needed on first run)...
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed

echo.
echo [3/4] Training and evaluating the machine-learning model...
.venv\Scripts\python.exe train_model.py
if errorlevel 1 goto failed

echo.
echo [4/4] Starting the web application...
echo The app will open in your browser. Keep this window open while using it.
echo Press Ctrl+C in this window to stop the app.
echo.
.venv\Scripts\python.exe -m streamlit run app.py
if errorlevel 1 goto failed
goto end

:no_python
echo ERROR: Python was not found.
echo Install Python 3.11 or newer from https://www.python.org/downloads/
echo During installation, tick "Add python.exe to PATH".
pause
exit /b 1

:failed
echo.
echo Something went wrong. Read the error above.
echo Check that Python is installed and that you have an internet connection.
pause
exit /b 1

:end
endlocal
