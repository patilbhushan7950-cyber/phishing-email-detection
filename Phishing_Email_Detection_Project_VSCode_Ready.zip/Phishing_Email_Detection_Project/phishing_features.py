"""Reusable feature extraction for email text and URL patterns."""
import re
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin

URL_RE = re.compile(r"https?://\S+|www\.\S+", re.IGNORECASE)
EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b")
SHORTENER_RE = re.compile(r"\b(bit\.ly|tinyurl\.com|t\.co|goo\.gl|ow\.ly|is\.gd)\b", re.IGNORECASE)
SUSPICIOUS_TERMS = (
    "verify", "urgent", "password", "suspended", "click here", "winner",
    "prize", "bank details", "confirm", "immediately", "account closure",
    "limited time", "payment failed", "credential", "claim your", "act now",
    "update your payment", "unlock", "unusual activity", "security alert"
)

class EmailFeatureExtractor(BaseEstimator, TransformerMixin):
    """Extract compact numeric features from raw email text."""

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        rows = []
        for raw in X:
            text = str(raw or "")
            lower = text.lower()
            urls = URL_RE.findall(text)
            rows.append([
                len(urls),
                int(any(url.lower().startswith("http://") for url in urls)),
                int("@" in text),
                int(bool(SHORTENER_RE.search(lower))),
                len(EMAIL_RE.findall(text)),
                sum(term in lower for term in SUSPICIOUS_TERMS),
                int("!" in text),
                int(bool(re.search(r"\b(verify|login|password|account|secure)\b", lower))),
                len(text),
                sum(ch.isupper() for ch in text) / max(len(text), 1),
            ])
        return np.asarray(rows, dtype=float)
