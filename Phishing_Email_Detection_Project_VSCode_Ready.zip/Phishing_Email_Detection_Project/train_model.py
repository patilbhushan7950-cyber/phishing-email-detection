"""Train and evaluate the phishing email classifier."""
from pathlib import Path
import json
import warnings

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    ConfusionMatrixDisplay, precision_score, recall_score, f1_score
)
from sklearn.linear_model import LogisticRegression
from phishing_features import EmailFeatureExtractor

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data" / "emails.csv"
MODEL_PATH = ROOT / "phishing_model.joblib"
CHART_PATH = ROOT / "confusion_matrix.png"
METRICS_PATH = ROOT / "model_metrics.json"
LABELS = ["phishing", "safe"]


def build_model():
    """Construct a scikit-learn pipeline combining TF-IDF and URL features."""
    features = FeatureUnion([
        ("text", TfidfVectorizer(
            lowercase=True,
            stop_words="english",
            ngram_range=(1, 2),
            max_features=12000,
            sublinear_tf=True,
        )),
        ("email_features", EmailFeatureExtractor()),
    ])
    return Pipeline([
        ("features", features),
        ("classifier", LogisticRegression(max_iter=2000, class_weight="balanced")),
    ])


def load_dataset():
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Dataset not found at {DATA_PATH}")
    df = pd.read_csv(DATA_PATH)
    required = {"text", "label"}
    if not required.issubset(df.columns):
        raise ValueError("CSV must contain 'text' and 'label' columns.")
    df = df.dropna(subset=["text", "label"]).copy()
    df["text"] = df["text"].astype(str).str.strip()
    df["label"] = df["label"].astype(str).str.strip().str.lower()
    df = df[(df["text"] != "") & df["label"].isin(LABELS)]
    df = df.drop_duplicates(subset=["text"]).reset_index(drop=True)
    if len(df) < 8 or set(df["label"]) != set(LABELS):
        raise ValueError("Please provide at least 8 unique emails and both labels: phishing and safe.")
    return df


def train_and_evaluate(verbose=True):
    df = load_dataset()
    X = df["text"]
    y = df["label"]
    # Keep the class proportions similar in train and test sets.
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    model = build_model()
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    cm = confusion_matrix(y_test, predictions, labels=LABELS)
    metrics = {
        "dataset_rows": int(len(df)),
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "accuracy": float(accuracy_score(y_test, predictions)),
        "phishing_precision": float(precision_score(y_test, predictions, pos_label="phishing", zero_division=0)),
        "phishing_recall": float(recall_score(y_test, predictions, pos_label="phishing", zero_division=0)),
        "phishing_f1": float(f1_score(y_test, predictions, pos_label="phishing", zero_division=0)),
        "labels": LABELS,
        "confusion_matrix": cm.tolist(),
        "classification_report": classification_report(
            y_test, predictions, labels=LABELS, target_names=["Phishing", "Safe"],
            output_dict=True, zero_division=0
        ),
        "dataset_note": "The included dataset is a small illustrative demo set; results do not represent real-world performance.",
    }

    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Phishing", "Safe"])
    disp.plot(values_format="d", cmap="Blues")
    plt.title("Confusion Matrix — Phishing Email Detection")
    plt.tight_layout()
    plt.savefig(CHART_PATH, dpi=160, bbox_inches="tight")
    plt.close()
    joblib.dump(model, MODEL_PATH)
    METRICS_PATH.write_text(json.dumps(metrics, indent=2), encoding="utf-8")

    if verbose:
        print("\n" + "=" * 58)
        print("       PHISHING EMAIL DETECTION — MODEL EVALUATION")
        print("=" * 58)
        print(f"Dataset rows     : {metrics['dataset_rows']}")
        print(f"Training samples : {metrics['train_rows']}")
        print(f"Testing samples  : {metrics['test_rows']}")
        print(f"Accuracy         : {metrics['accuracy']:.2%}")
        print(f"Phishing precision: {metrics['phishing_precision']:.2%}")
        print(f"Phishing recall   : {metrics['phishing_recall']:.2%}")
        print(f"Phishing F1-score : {metrics['phishing_f1']:.2%}")
        print("\nClassification report:")
        print(classification_report(y_test, predictions, labels=LABELS, target_names=["Phishing", "Safe"], zero_division=0))
        print(f"Confusion matrix saved to: {CHART_PATH}")
        print(f"Trained model saved to: {MODEL_PATH}")
        print("\nIMPORTANT: Results use a small demo dataset and are not evidence of real-world accuracy.")
    return model, metrics


def main():
    train_and_evaluate(verbose=True)

if __name__ == "__main__":
    main()
