# Phishing Email Detection Model — VS Code Ready

This project uses **Scikit-learn**, TF-IDF text features, URL-related features, and Logistic Regression to classify email text as `phishing` or `safe`. It includes an interactive Streamlit web app, evaluation metrics, and a confusion-matrix image.

## Easiest way (Windows)

1. Download and extract the ZIP file into a normal folder such as `Desktop\Phishing_Email_Detection_Project`.
2. Install **Python 3.11 or newer** from <https://www.python.org/downloads/> if it is not already installed. During installation, select **Add Python to PATH**.
3. Open the extracted folder in VS Code: **File → Open Folder**.
4. Double-click **`START_PROJECT.bat`** in File Explorer, or right-click it and choose **Open**. It creates `.venv`, installs libraries, trains the model, and starts the app. Internet is required for installing libraries on the first run.
5. The web app opens in your browser. Keep the terminal window open while using it.

You can also run `START_PROJECT.bat` directly without VS Code; VS Code is useful for reading and editing the source code.

## Run from the VS Code terminal

Open **Terminal → New Terminal** in the project folder and enter these commands on Windows:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe train_model.py
.\.venv\Scripts\python.exe -m streamlit run app.py
```

If `.venv` already exists, you do not need to create it again. If PowerShell blocks activation, the commands above still work because they use the virtual environment's Python directly.

## Files

- `app.py` — interactive web UI to analyze email subject/body.
- `train_model.py` — trains and evaluates the model and saves its outputs.
- `phishing_features.py` — reusable URL/text feature extraction code, kept separate so the saved model loads correctly in the app.
- `data/emails.csv` — included, small labelled demo dataset.
- `requirements.txt` — required packages.
- `.vscode/` — workspace settings and a training debug configuration.
- `START_PROJECT.bat` — Windows setup/run helper.

Optional smoke test after training:

```powershell
.\.venv\Scripts\python.exe test_model.py
```

Generated after training:

- `phishing_model.joblib` — saved model pipeline.
- `model_metrics.json` — evaluation metrics.
- `confusion_matrix.png` — confusion matrix visualization.

## Dataset format

To use another dataset, replace `data/emails.csv` while preserving the column names `text,label`. Each label must be `phishing` or `safe`. Use a trusted, appropriately licensed dataset, remove duplicates, and avoid leakage between train and test data.

## Important limitations

The bundled dataset is a **small illustrative teaching dataset**, not a validated real-world benchmark. Its accuracy may appear high or low depending on the sample split and is not evidence of real-world phishing-detection performance. The classifier learns patterns from examples and can make mistakes. A prediction of `safe` is not a guarantee; do not use the project as the only security control.
