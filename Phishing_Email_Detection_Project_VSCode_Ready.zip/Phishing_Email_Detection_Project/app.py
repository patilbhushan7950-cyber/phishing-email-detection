"""Streamlit interface for the Phishing Email Detection model."""
from pathlib import Path
import json

import joblib
import streamlit as st
from train_model import train_and_evaluate

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "phishing_model.joblib"
METRICS_PATH = ROOT / "model_metrics.json"
CHART_PATH = ROOT / "confusion_matrix.png"

st.set_page_config(
    page_title="Phishing Email Detector",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
.main-header {padding: 1.2rem 1.4rem; border-radius: 18px; background: linear-gradient(115deg,#10243a,#174b68); color: white; margin-bottom: 1rem;}
.main-header h1 {color: white; margin: 0; font-size: 2.15rem;}
.main-header p {color: #d8e8f2; margin: .45rem 0 0 0;}
.small-muted {color: #64748b; font-size: .9rem;}
div[data-testid="stMetric"] {background: #f5f8fb; border: 1px solid #e2e8f0; padding: 12px 16px; border-radius: 12px;}
</style>
<div class="main-header">
  <h1>🛡️ Phishing Email Detector</h1>
  <p>Machine learning that analyzes email wording and URL patterns to flag suspicious messages.</p>
</div>
""", unsafe_allow_html=True)

@st.cache_resource
def load_or_train_model():
    if not MODEL_PATH.exists() or not METRICS_PATH.exists():
        return train_and_evaluate(verbose=False)[0]
    return joblib.load(MODEL_PATH)

try:
    model = load_or_train_model()
except Exception as exc:
    st.error(f"Could not load or train the model: {exc}")
    st.info("Check that data/emails.csv exists and contains 'text' and 'label' columns.")
    st.stop()

with st.sidebar:
    st.header("About this project")
    st.write("**Algorithm:** Logistic Regression")
    st.write("**Text features:** TF-IDF word and phrase patterns")
    st.write("**Extra features:** URL count, HTTP links, URL shorteners, suspicious terms, and text patterns")
    st.divider()
    st.warning("Educational prototype only. A 'Safe' prediction is not a guarantee. Never enter passwords, one-time codes, or other private information into a message to verify it.")
    if st.button("Retrain model", use_container_width=True):
        with st.spinner("Training the model from data/emails.csv..."):
            try:
                train_and_evaluate(verbose=False)
                load_or_train_model.clear()
                st.success("Model retrained successfully.")
                st.rerun()
            except Exception as exc:
                st.error(f"Training failed: {exc}")

analyze_tab, performance_tab, instructions_tab = st.tabs(["🔎 Analyze an email", "📊 Model performance", "📘 How it works"])

with analyze_tab:
    left, right = st.columns([1.5, 1])
    with left:
        st.subheader("Email content")
        sample = st.selectbox("Try a sample", ["Choose a sample...", "Suspicious account warning", "Normal meeting reminder"])
        default_text = ""
        if sample == "Suspicious account warning":
            default_text = "URGENT: Your account will be suspended! Verify your password immediately at http://secure-account-verify.example/login"
        elif sample == "Normal meeting reminder":
            default_text = "Hello team, the project meeting is scheduled for tomorrow at 10 AM. Please review the agenda before the call."
        email_text = st.text_area(
            "Paste the email subject and body",
            value=default_text,
            height=240,
            placeholder="Subject: ...\n\nEmail body: ...",
            help="For best results, include both the subject and body. You may remove names or private information first.",
            label_visibility="collapsed",
        )
        analyze = st.button("Analyze email", type="primary", use_container_width=True)
    with right:
        st.subheader("Signals checked")
        st.markdown("- **Text patterns:** suspicious words and phrases\n- **URLs:** number and type of links\n- **Link patterns:** HTTP links and common shorteners\n- **Message style:** punctuation and uppercase patterns")
        st.caption("These are statistical clues, not proof that a message is malicious.")

    if analyze:
        if not email_text.strip():
            st.warning("Paste an email's subject or body before analyzing it.")
        else:
            prediction = str(model.predict([email_text])[0])
            probabilities = model.predict_proba([email_text])[0]
            classes = list(model.classes_)
            confidence = float(probabilities[classes.index(prediction)])
            st.divider()
            st.subheader("Analysis result")
            result_col, confidence_col = st.columns(2)
            with result_col:
                if prediction == "phishing":
                    st.error("🚨 PHISHING — suspicious email patterns detected")
                else:
                    st.success("✅ SAFE-LABELED — the model did not classify this as phishing")
            with confidence_col:
                st.metric("Model confidence", f"{confidence:.1%}")
            st.progress(confidence)
            st.caption("Confidence is the model's estimated probability, not a guarantee of safety. Independently verify unexpected requests using an official app, website, or known phone number.")

with performance_tab:
    st.subheader("Evaluation on a held-out test split")
    if METRICS_PATH.exists():
        metrics = json.loads(METRICS_PATH.read_text(encoding="utf-8"))
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Accuracy", f"{metrics['accuracy']:.1%}")
        m2.metric("Phishing precision", f"{metrics['phishing_precision']:.1%}")
        m3.metric("Phishing recall", f"{metrics['phishing_recall']:.1%}")
        m4.metric("Phishing F1-score", f"{metrics['phishing_f1']:.1%}")
        c1, c2 = st.columns([1, 1])
        with c1:
            if CHART_PATH.exists():
                st.image(str(CHART_PATH), caption="Confusion matrix: actual labels versus model predictions", use_container_width=True)
        with c2:
            st.write(f"**Dataset rows:** {metrics['dataset_rows']}")
            st.write(f"**Training rows:** {metrics['train_rows']}")
            st.write(f"**Test rows:** {metrics['test_rows']}")
            st.warning(metrics.get("dataset_note", "Evaluation depends on dataset quality."))
    else:
        st.info("Evaluation metrics will appear after training the model.")

with instructions_tab:
    st.subheader("Workflow")
    st.markdown("""
    1. **Load labelled data** from `data/emails.csv`.
    2. **Preprocess text** and convert words and two-word phrases into TF-IDF features.
    3. **Extract URL/text signals** such as URL count, plain HTTP links, shorteners, and suspicious words.
    4. **Train Logistic Regression** using the combined features.
    5. **Evaluate** on a held-out test split with accuracy, precision, recall, F1-score, and a confusion matrix.
    6. **Predict** whether a newly entered message resembles the phishing or safe examples.

    **Dataset format:** the CSV must have `text` and `label` columns. Labels must be `phishing` or `safe`.

    **Academic limitation:** the bundled data is a small illustrative dataset created for demonstration. Do not describe its test accuracy as real-world performance. Use a larger, trusted, appropriately licensed dataset and a carefully separated test set for a meaningful evaluation.
    """)

st.divider()
st.markdown('<p class="small-muted">Phishing Email Detection Model · Scikit-learn + Streamlit · Educational use</p>', unsafe_allow_html=True)
